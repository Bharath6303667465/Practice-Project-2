package phase1;

public class SleepWaitDemo {
    public static void main(String[] args) {
        final Object lock = new Object();

        // Thread using sleep()
        Thread sleepThread = new Thread(() -> {
            synchronized (lock) {
                System.out.println("Sleep Thread started.");
                try {
                    Thread.sleep(3000); // Sleep for 3 seconds
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("Sleep Thread resumed after sleep.");
            }
        });

        // Thread using wait()
        Thread waitThread = new Thread(() -> {
            synchronized (lock) {
                System.out.println("Wait Thread started.");
                try {
                    lock.wait(); // Wait until notified
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("Wait Thread resumed after wait.");
            }
        });

        sleepThread.start();
        waitThread.start();

        try {
            Thread.sleep(1000); // Delay to ensure waitThread starts first
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        synchronized (lock) {
            lock.notify(); // Notify the waiting thread
        }

        try {
            sleepThread.join();
            waitThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Main Thread exiting.");
    }
}
