package phase1;

class CustomException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomException(String message) {
        super(message);
    }
}

public class ExceptionDemo {
    public static void main(String[] args) {
        try {
            performOperation();
        } catch (CustomException e) {
            System.out.println("Caught CustomException: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed.");
        }
    }

    public static void performOperation() throws CustomException {
        try {
            int result = divide(10, 0);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            throw new CustomException("Cannot divide by zero.");
        }
    }

    public static int divide(int dividend, int divisor) {
        return dividend / divisor;
    }
}
