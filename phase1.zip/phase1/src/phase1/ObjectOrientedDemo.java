package phase1;

//Parent class
class Animal {
 private String name;

 public Animal(String name) {
     this.name = name;
 }

 public void eat() {
     System.out.println(name + " is eating.");
 }

 public void sleep() {
     System.out.println(name + " is sleeping.");
 }
}

//Child class inheriting from Animal
class Dog extends Animal {
 public Dog(String name) {
     super(name);
 }

 public void bark() {
     System.out.println("Dog is barking.");
 }
}

//Interface
interface Jumpable {
 void jump();
}

//Class implementing the Jumpable interface
class Cat implements Jumpable {
 public void jump() {
     System.out.println("Cat is jumping.");
 }
}

//Abstract class
abstract class Vehicle {
 protected String brand;

 public Vehicle(String brand) {
     this.brand = brand;
 }

 abstract void drive();
}

//Concrete class extending the abstract class
class Car extends Vehicle {
 public Car(String brand) {
     super(brand);
 }

 void drive() {
     System.out.println(brand + " car is driving.");
 }
}

public class ObjectOrientedDemo {
 public static void main(String[] args) {
     // Creating objects
     Animal animal = new Animal("Animal");
     Dog dog = new Dog("Dog");
     Cat cat = new Cat();
     Car car = new Car("Toyota");

     // Calling methods and demonstrating encapsulation
     animal.eat();
     dog.eat();
     dog.sleep();
     dog.bark();
     cat.jump();
     car.drive();

     // Demonstrating polymorphism and inheritance
     Animal polymorphicDog = new Dog("Polymorphic Dog");
     polymorphicDog.eat();
     polymorphicDog.sleep();
     // polymorphicDog.bark(); // Cannot access bark() method using polymorphic reference

     // Demonstrating abstraction
     Vehicle vehicle = new Car("Honda");
     vehicle.drive();
 }
}
