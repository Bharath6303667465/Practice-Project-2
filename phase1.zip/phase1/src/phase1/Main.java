package phase1;

//Create a thread by extending the 'Thread' class
class MyThread extends Thread {
 public void run() {
     System.out.println("Thread extended from 'Thread' class is running.");
 }
}

//Create a thread by implementing the 'Runnable' interface
class MyRunnable implements Runnable {
 public void run() {
     System.out.println("Thread implemented from 'Runnable' interface is running.");
 }
}

public class Main {
 public static void main(String[] args) {
     // Create and start a thread extended from 'Thread' class
     MyThread myThread = new MyThread();
     myThread.start();

     // Create and start a thread implemented from 'Runnable' interface
     MyRunnable myRunnable = new MyRunnable();
     Thread thread = new Thread(myRunnable);
     thread.start();
 }
}
