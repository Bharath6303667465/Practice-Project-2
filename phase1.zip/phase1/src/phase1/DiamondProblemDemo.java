package phase1;

//Interface A
interface A {
 default void display() {
     System.out.println("This is interface A");
 }
}

//Interface B extending A
interface B extends A {
 default void display() {
     System.out.println("This is interface B");
 }
}

//Interface C extending A
interface C extends A {
 default void display() {
     System.out.println("This is interface C");
 }
}

//Class implementing B and C
class D implements B, C {
 public void display() {
     B.super.display(); // Resolving the diamond problem
     C.super.display(); // Resolving the diamond problem
     System.out.println("This is class D");
 }
}

public class DiamondProblemDemo {
 public static void main(String[] args) {
     D d = new D();
     d.display();
 }
}

