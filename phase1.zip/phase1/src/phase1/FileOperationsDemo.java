package phase1;

import java.io.*;

public class FileOperationsDemo {
    public static void main(String[] args) {
        String fileName = "sample.txt";

        // Create a new file
        createFile(fileName);

        // Write content to the file
        String content = "Hello, World!";
        writeFile(fileName, content);

        // Read and display the file content
        String fileContent = readFile(fileName);
        System.out.println("File Content: " + fileContent);

        // Update the file content
        String updatedContent = "Hello, OpenAI!";
        updateFile(fileName, updatedContent);

        // Read and display the updated file content
        String updatedFileContent = readFile(fileName);
        System.out.println("Updated File Content: " + updatedFileContent);

        // Delete the file
        deleteFile(fileName);
    }

    public static void createFile(String fileName) {
        File file = new File(fileName);
        try {
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file.");
            e.printStackTrace();
        }
    }

    public static void writeFile(String fileName, String content) {
        try (FileWriter writer = new FileWriter(fileName)) {
            writer.write(content);
            System.out.println("Content written to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }
    }

    public static String readFile(String fileName) {
        StringBuilder fileContent = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                fileContent.append(line);
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
        return fileContent.toString();
    }

    public static void updateFile(String fileName, String updatedContent) {
        try (FileWriter writer = new FileWriter(fileName, false)) {
            writer.write(updatedContent);
            System.out.println("File content updated.");
        } catch (IOException e) {
            System.out.println("An error occurred while updating the file.");
            e.printStackTrace();
        }
    }

    public static void deleteFile(String fileName) {
        File file = new File(fileName);
        if (file.delete()) {
            System.out.println("File deleted: " + fileName);
        } else {
            System.out.println("Failed to delete the file.");
        }
    }
}
